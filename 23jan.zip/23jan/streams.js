var fs = require("fs");
var data = '';

// Create a readable stream
var readerStream = fs.createReadStream('/Users/nitishgupta/Downloads/pycharm-community-2017.2.3.dmg');

// Set the encoding to be utf8. 
readerStream.setEncoding('UTF8');

// Handle stream events --> data, end, and error
readerStream.on('data', function(chunk) {
   data += chunk;
   console.log("______________________________________",chunk.length,"-----",data.length)
});

readerStream.on('end',function(){
   console.log(data);
});

readerStream.on('error', function(err){
   console.log(err.stack);
});

// var fs = require("fs")

// // Create a readable stream
// var readerStream = fs.createReadStream('input.txt');

// // Create a writable stream
// var writerStream = fs.createWriteStream('output.txt');

// console.log(readerStream)
// // Pipe the read and write operations
// // read input.txt and write data to output.txt
// readerStream.pipe(writerStream);

// console.log("Program Ended");