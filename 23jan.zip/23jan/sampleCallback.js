// var string = process.argv[2];//process.agrv[i]- basically loops through the command line arguments passed in the terminal while executing the file
// var num1 = num2=0;
// strings = string.replace(/[0-9]+/g, "#").replace(/[\(|\|\.)]/g, "");
// var operators = strings.split("#").filter(function(n){return n});

// if(string.indexOf(operators) !='-1'){
//     num1 = Number(string.slice(0,string.indexOf(operators[0]))); //The indexOf() method returns the position of the first occurrence of a specified value in a string.
//     num2 = Number(string.slice(string.indexOf(operators[0])+1)); //The slice() method returns the selected elements in an array, as a new array object.
//     console.log(num1 +operators[0]+ num2);
    
// }


//Main.js
// var values=require('./Calculate');

 a = process.argv;
//  node 
console.log(process.argv)
 var arrayOfStrings = a[2].split('+');
console.log(arrayOfStrings)
//console.log(values.add(a,b));

//calculate.js
exports.add = (a,b)=>a+b;
exports.Sub = (a,b)=>a-b;
exports.Mul = (a,b)=>a*b;
exports.Div = (a,b)=>a/b;