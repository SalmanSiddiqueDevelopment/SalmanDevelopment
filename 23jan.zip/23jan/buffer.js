buf = new Buffer(256);
len = buf.write("We learn at Zenways");

console.log("Octets written : "+  len);


console.log(typeof(len))

console.log(buf.readInt8(0))