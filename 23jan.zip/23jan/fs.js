const fs = require('fs');

// // fs.unlink('./random.file', (err) => {
// //   if (err) throw err;
// //   console.log('successfully deleted /tmp/hello');
// // });
// fs.appendFile('message.txt', process.argv[2], (err) => {
//     if (err) throw err;
//     console.log('The "data to append" was appended to file!');
//   });

fs.readFile('./message.txt', 'utf-8',(err, data) => {
    if (err) throw err;
    console.log(data);
  });
  