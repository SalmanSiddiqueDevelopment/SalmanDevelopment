var events = require('events');
var eventEmitter = new events.EventEmitter();
var ringBell = function ringBell() // A regular function
{
  console.log('SOME FUNCTION');
}
var ringBell1 = function ringBell() // A regular function
{
  console.log('SOME FUNCTION1');
}
var ringBell2 = function ringBell() // A regular function
{
  console.log('SOME FUNCTION2');
}
var ringBell3 = function ringBell() // A regular function
{
  console.log('SOME FUNCTION3');
}
eventEmitter.on('doorOpen', ringBell); //Adding doorOpen event -> ringBell function
eventEmitter.on('doorOpen', ringBell1); //Adding doorOpen event -> ringBell function
eventEmitter.on('doorOpen', ringBell2); //Adding doorOpen event -> ringBell function
eventEmitter.on('doorOpen', ringBell3); //Adding doorOpen event -> ringBell function

eventEmitter.emit('doorOpen');// Calling the emit() method will execute all the function //registered with on method
