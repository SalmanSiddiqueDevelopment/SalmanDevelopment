var hello = 10;
//# sourceMappingURL=secType.js.map