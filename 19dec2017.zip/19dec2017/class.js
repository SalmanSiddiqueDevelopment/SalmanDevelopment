// var myCar = new Object();
// myCar.make = 'Ford';
// myCar.model = 'Mustang';
// myCar.year = 1969;

// console.log(myCar)


// var myNewCar = {
//     make: 'Maruti',
//     model: 'Alto',
//     engineType: 'Petrol',
//     cc: 800
// }

// console.log(myNewCar.model)
// console.log(typeof (myNewCar))
// console.log(myNewCar)


// function Car(make, model, year) {
//     this.make = make;
//     this.model = model;
//     this.year = year;

//     this.getCar = function() {
//         return this.make
//     };
    
// }

// var newCar = new Car('Mahindra','Scorpio',2017)

// console.log( typeof (newCar))
// console.log(newCar.getCar())

// var obj = {a: 1, b: 2, c: 3};
    
// for (var abc in obj) {
//   console.log(`obj.${abc} = ${obj[abc]}`);
// }
