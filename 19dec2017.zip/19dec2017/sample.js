//Number.isFinite()
function checkNo(b) // disussion
{
    if (isFinite(b) != false) {
        console.log(isFinite(b))
        a = Number.parseInt(b)
        a = a - parseInt(100.12);
        console.log("Definednumber", a);
    } else
        console.log(b, 'Undefined number')
}
// checkNo('-11111111111111111111111')
checkNo(1 / 0)