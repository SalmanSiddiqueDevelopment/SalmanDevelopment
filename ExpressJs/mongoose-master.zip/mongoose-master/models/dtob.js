// var abc = "hsgfkskjlfs"

// var bcd = abc.slice(-2, -1)
// console.log(bcd)
// console.log(abc.charAt(6))
// console.log(abc.indexOf('kjl'))

// var greatest = (array)=>{
//     for()
// }

// var arr = ['dfjkbj', 345];
// var arr2 = [...arr]; //arr2 =arr
// arr[2] = 'fsh'
// console.log(arr, arr2)

var abc = ['hh', 'Jk'];
// console.log(abc.join("--"))
// console.log(abc.sort())
var n = 'dsgjsi'


abc.push('dvhvh')
abc.pop()
abc.unshift('cbhjxhv')
abc.shift()