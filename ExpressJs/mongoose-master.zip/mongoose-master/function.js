// var fileSystem = require('fs')
// var rn = require('random-number')
// console.log(rn())
// // fileSystem.open('abc.txt', 'w', (err, data) => {
// //     if (err) {
// //         console.log(err)
// //     } else {
// //         console.log("File created")
// //     }
// // })
// var x = "sjkjgedykufehdkuhaeiudz"
// fileSystem.writeFile('xyz1.txt', x, (err, data) => {
//     if (err) {
//         console.log(err)
//     } else {
//         console.log("File created")
//     }
// })

// fileSystem.appendFile('xyz.txt', x, (err, data) => {
//     if (err) {
//         console.log(err)
//     } else {
//         console.log("File created")
//     }
// })

// fileSystem.readFile('xyz.txt', 'utf8', (err, data) => {
//     if (err) {
//         console.log(err)
//     } else {
//         console.log(data)
//     }
// })