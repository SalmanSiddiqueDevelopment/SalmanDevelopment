exports.multiply = (a, b) => {
    return a * b
}