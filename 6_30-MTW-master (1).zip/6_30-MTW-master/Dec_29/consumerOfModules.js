"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var modules_1 = require("./modules");
var cons = new modules_1.m1.one();
//# sourceMappingURL=consumerOfModules.js.map