import { m1 } from './modules';

var cons = new m1.one();
