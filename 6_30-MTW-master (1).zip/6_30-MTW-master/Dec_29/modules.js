"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var m1;
(function (m1) {
    var one = /** @class */ (function () {
        function one() {
            this.className = 'ondvcdfe';
        }
        return one;
    }());
    m1.one = one;
})(m1 = exports.m1 || (exports.m1 = {}));
var m2;
(function (m2) {
    var two = new m1.one();
    console.log(two.className);
})(m2 || (m2 = {}));
var three = new m1.one();
//# sourceMappingURL=modules.js.map